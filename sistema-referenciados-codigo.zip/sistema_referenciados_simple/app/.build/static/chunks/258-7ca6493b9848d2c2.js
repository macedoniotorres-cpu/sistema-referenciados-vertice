(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[258],{3934:function(e,t,r){"use strict";r.d(t,{Z:function(){return o}});let o=(0,r(2154).Z)("Banknote",[["rect",{width:"20",height:"12",x:"2",y:"6",rx:"2",key:"9lu3g6"}],["circle",{cx:"12",cy:"12",r:"2",key:"1c9p78"}],["path",{d:"M6 12h.01M18 12h.01",key:"113zkx"}]])},7248:function(e,t,r){"use strict";r.d(t,{Z:function(){return o}});let o=(0,r(2154).Z)("Check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]])},9062:function(e,t,r){"use strict";r.d(t,{Z:function(){return o}});let o=(0,r(2154).Z)("Crown",[["path",{d:"M11.562 3.266a.5.5 0 0 1 .876 0L15.39 8.87a1 1 0 0 0 1.516.294L21.183 5.5a.5.5 0 0 1 .798.519l-2.834 10.246a1 1 0 0 1-.956.734H5.81a1 1 0 0 1-.957-.734L2.02 6.02a.5.5 0 0 1 .798-.519l4.276 3.664a1 1 0 0 0 1.516-.294z",key:"1vdc57"}],["path",{d:"M5 21h14",key:"11awu3"}]])},6584:function(e,t,r){"use strict";r.d(t,{Z:function(){return o}});let o=(0,r(2154).Z)("Download",[["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["polyline",{points:"7 10 12 15 17 10",key:"2ggqvy"}],["line",{x1:"12",x2:"12",y1:"15",y2:"3",key:"1vk2je"}]])},5011:function(e,t,r){"use strict";r.d(t,{Z:function(){return o}});let o=(0,r(2154).Z)("Printer",[["path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2",key:"143wyd"}],["path",{d:"M6 9V3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v6",key:"1itne7"}],["rect",{x:"6",y:"14",width:"12",height:"8",rx:"1",key:"1ue0tg"}]])},1509:function(e,t,r){"use strict";r.d(t,{Z:function(){return o}});let o=(0,r(2154).Z)("Receipt",[["path",{d:"M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z",key:"q3az6g"}],["path",{d:"M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8",key:"1h4pet"}],["path",{d:"M12 17.5v-11",key:"1jc1ny"}]])},9484:function(e,t,r){"use strict";r.d(t,{Z:function(){return o}});let o=(0,r(2154).Z)("Shield",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}]])},3851:function(e,t,r){"use strict";r.d(t,{Z:function(){return o}});let o=(0,r(2154).Z)("UserMinus",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["line",{x1:"22",x2:"16",y1:"11",y2:"11",key:"1shjgl"}]])},5397:function(e,t,r){"use strict";r.d(t,{Z:function(){return o}});let o=(0,r(2154).Z)("UserPlus",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["line",{x1:"19",x2:"19",y1:"8",y2:"14",key:"1bvyxn"}],["line",{x1:"22",x2:"16",y1:"11",y2:"11",key:"1shjgl"}]])},4693:function(e,t,r){"use strict";r.d(t,{Z:function(){return o}});let o=(0,r(2154).Z)("User",[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]])},3485:function(e,t,r){"use strict";r.d(t,{Z:function(){return o}});let o=(0,r(2154).Z)("X",[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]])},7319:function(e,t,r){var o;"undefined"!=typeof self&&self,o=function(e){return function(){"use strict";var t={155:function(t){t.exports=e}},r={};function o(e){var n=r[e];if(void 0!==n)return n.exports;var i=r[e]={exports:{}};return t[e](i,i.exports,o),i.exports}o.d=function(e,t){for(var r in t)o.o(t,r)&&!o.o(e,r)&&Object.defineProperty(e,r,{enumerable:!0,get:t[r]})},o.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},o.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})};var n={};o.r(n),o.d(n,{useReactToPrint:function(){return u}});var i=o(155);function s({level:e="error",messages:t,suppressErrors:r=!1}){r||("error"===e?console.error(t):"warning"===e?console.warn(t):console.debug(t))}function a(e,t){if(t||!e){let e=document.getElementById("printWindow");e&&document.body.removeChild(e)}}function l(e){return e instanceof Error?e:Error("Unknown Error")}function d(e,t){let{documentTitle:r,onAfterPrint:o,onPrintError:n,preserveAfterPrint:i,print:d,suppressErrors:c}=t;setTimeout(()=>{var t,u;if(e.contentWindow){function p(){null==o||o(),a(i)}if(e.contentWindow.focus(),d)d(e).then(p).catch(e=>{n?n("print",l(e)):s({messages:["An error was thrown by the specified `print` function"],suppressErrors:c})});else{if(e.contentWindow.print){let o=null!==(u=null===(t=e.contentDocument)||void 0===t?void 0:t.title)&&void 0!==u?u:"",n=e.ownerDocument.title;r&&(e.ownerDocument.title=r,e.contentDocument&&(e.contentDocument.title=r)),e.contentWindow.print(),r&&(e.ownerDocument.title=n,e.contentDocument&&(e.contentDocument.title=o))}else s({messages:["Printing for this browser is not currently possible: the browser does not have a `print` method available for iframes."],suppressErrors:c});[/Android/i,/webOS/i,/iPhone/i,/iPad/i,/iPod/i,/BlackBerry/i,/Windows Phone/i].some(e=>{var t,r;return(null!==(r=null!==(t=navigator.userAgent)&&void 0!==t?t:navigator.vendor)&&void 0!==r?r:"opera"in window&&window.opera).match(e)})?setTimeout(p,500):p()}}else s({messages:["Printing failed because the `contentWindow` of the print iframe did not load. This is possibly an error with `react-to-print`. Please file an issue: https://github.com/MatthewHerbst/react-to-print/issues/"],suppressErrors:c})},500)}function c(e){let t=[],r=document.createTreeWalker(e,NodeFilter.SHOW_ELEMENT,null),o=r.nextNode();for(;o;)t.push(o),o=r.nextNode();return t}function u({bodyClass:e,contentRef:t,copyShadowRoots:r,documentTitle:o,fonts:n,ignoreGlobalStyles:u,nonce:p,onAfterPrint:f,onBeforePrint:m,onPrintError:h,pageStyle:y,preserveAfterPrint:g,print:b,suppressErrors:v}){return(0,i.useCallback)(i=>{function w(){let a={bodyClass:e,contentRef:t,copyShadowRoots:r,documentTitle:o,fonts:n,ignoreGlobalStyles:u,nonce:p,onAfterPrint:f,onBeforePrint:m,onPrintError:h,pageStyle:y,preserveAfterPrint:g,print:b,suppressErrors:v},w=function(){let e=document.createElement("iframe");return e.width=`${document.documentElement.clientWidth}px`,e.height=`${document.documentElement.clientHeight}px`,e.style.position="absolute",e.style.top=`-${document.documentElement.clientHeight+100}px`,e.style.left=`-${document.documentElement.clientWidth+100}px`,e.id="printWindow",e.srcdoc="<!DOCTYPE html>",e}(),x=function(e,t){let{contentRef:r,fonts:o,ignoreGlobalStyles:n,suppressErrors:i}=t,a=function({contentRef:e,optionalContent:t,suppressErrors:r}){return t&&"function"==typeof t?(e&&s({level:"warning",messages:['"react-to-print" received a `contentRef` option and an optional-content param passed to its callback. The `contentRef` option will be ignored.']}),t()):e?e.current:void s({messages:['"react-to-print" did not receive a `contentRef` option or a optional-content param pass to its callback.'],suppressErrors:r})}({contentRef:r,optionalContent:e,suppressErrors:i});if(!a)return;let l=a.cloneNode(!0),d=document.querySelectorAll("link[rel~='stylesheet'], link[as='style']"),c=l.querySelectorAll("img"),u=l.querySelectorAll("video"),p=o?o.length:0;return{contentNode:a,clonedContentNode:l,clonedImgNodes:c,clonedVideoNodes:u,numResourcesToLoad:(n?0:d.length)+c.length+u.length+p,originalCanvasNodes:a.querySelectorAll("canvas")}}(i,a);if(!x)return void s({messages:["There is nothing to print"],suppressErrors:v});let k=function(e,t,r){let{suppressErrors:o}=e,n=[],i=[];return function(a,l){n.includes(a)?s({level:"debug",messages:["Tried to mark a resource that has already been handled",a],suppressErrors:o}):(l?(s({messages:['"react-to-print" was unable to load a resource but will continue attempting to print the page',...l],suppressErrors:o}),i.push(a)):n.push(a),n.length+i.length===t&&d(r,e))}}(a,x.numResourcesToLoad,w);w.onload=()=>{(function(e,t,r,o){var n,i,a,u,p;let{contentNode:f,clonedContentNode:m,clonedImgNodes:h,clonedVideoNodes:y,numResourcesToLoad:g,originalCanvasNodes:b}=r,{bodyClass:v,fonts:w,ignoreGlobalStyles:x,pageStyle:k,nonce:E,suppressErrors:A,copyShadowRoots:C}=o;e.onload=null;let P=null!==(n=e.contentDocument)&&void 0!==n?n:null===(i=e.contentWindow)||void 0===i?void 0:i.document;if(P){let r=P.body.appendChild(m);C&&function e(t,r,o){let n=c(t),i=c(r);if(n.length===i.length)for(let t=0;t<n.length;t++){let r=n[t],s=i[t],a=r.shadowRoot;if(null!==a){let t=s.attachShadow({mode:a.mode});t.innerHTML=a.innerHTML,e(a,t,o)}}else s({messages:["When cloning shadow root content, source and target elements have different size. `onBeforePrint` likely resolved too early.",t,r],suppressErrors:o})}(f,r,!!A),w&&((null===(a=e.contentDocument)||void 0===a?void 0:a.fonts)&&(null===(u=e.contentWindow)||void 0===u?void 0:u.FontFace)?w.forEach(r=>{let o=new FontFace(r.family,r.source,{weight:r.weight,style:r.style});e.contentDocument.fonts.add(o),o.loaded.then(()=>{t(o)}).catch(e=>{t(o,["Failed loading the font:",o,"Load error:",l(e)])})}):(w.forEach(e=>{t(e)}),s({messages:['"react-to-print" is not able to load custom fonts because the browser does not support the FontFace API but will continue attempting to print the page'],suppressErrors:A})));let o=P.createElement("style");E&&(o.setAttribute("nonce",E),P.head.setAttribute("nonce",E)),o.appendChild(P.createTextNode(null!=k?k:'\n    @page {\n        /* Remove browser default header (title) and footer (url) */\n        margin: 0;\n    }\n    @media print {\n        body {\n            /* Tell browsers to print background colors */\n            color-adjust: exact; /* Firefox. This is an older version of "print-color-adjust" */\n            print-color-adjust: exact; /* Firefox/Safari */\n            -webkit-print-color-adjust: exact; /* Chrome/Safari/Edge/Opera */\n        }\n    }\n')),P.head.appendChild(o),v&&P.body.classList.add(...v.split(" "));let n=P.querySelectorAll("canvas");for(let e=0;e<b.length;++e){let t=b[e],r=n[e];if(void 0===r){s({messages:["A canvas element could not be copied for printing, has it loaded? `onBeforePrint` likely resolved too early.",t],suppressErrors:A});continue}let o=r.getContext("2d");o&&o.drawImage(t,0,0)}for(let e=0;e<h.length;e++){let r=h[e],o=r.getAttribute("src");if(o){let e=new Image;e.onload=()=>{t(r)},e.onerror=(e,o,n,i,s)=>{t(r,["Error loading <img>",r,"Error",s])},e.src=o}else t(r,['Found an <img> tag with an empty "src" attribute. This prevents pre-loading it.',r])}for(let e=0;e<y.length;e++){let r=y[e];r.preload="auto";let o=r.getAttribute("poster");if(o){let e=new Image;e.onload=()=>{t(r)},e.onerror=(e,n,i,s,a)=>{t(r,["Error loading video poster",o,"for video",r,"Error:",a])},e.src=o}else r.readyState>=2?t(r):r.src?(r.onloadeddata=()=>{t(r)},r.onerror=(e,o,n,i,s)=>{t(r,["Error loading video",r,"Error",s])},r.onstalled=()=>{t(r,["Loading video stalled, skipping",r])}):t(r,["Error loading video, `src` is empty",r])}let i="select",d=f.querySelectorAll(i),g=P.querySelectorAll(i);for(let e=0;e<d.length;e++)g[e].value=d[e].value;if(!x){let e=document.querySelectorAll("style, link[rel~='stylesheet'], link[as='style']");for(let r=0,o=e.length;r<o;++r){let o=e[r];if("style"===o.tagName.toLowerCase()){let e=P.createElement(o.tagName),t=o.sheet;if(t){let n="";try{let e=t.cssRules.length;for(let r=0;r<e;++r)"string"==typeof t.cssRules[r].cssText&&(n+=`${t.cssRules[r].cssText}\r
`)}catch(e){s({messages:["A stylesheet could not be accessed. This is likely due to the stylesheet having cross-origin imports, and many browsers block script access to cross-origin stylesheets. See https://github.com/MatthewHerbst/react-to-print/issues/429 for details. You may be able to load the sheet by both marking the stylesheet with the cross `crossorigin` attribute, and setting the `Access-Control-Allow-Origin` header on the server serving the stylesheet. Alternatively, host the stylesheet on your domain to avoid this issue entirely.",o,`Original error: ${l(e).message}`],level:"warning"})}e.setAttribute("id",`react-to-print-${r}`),E&&e.setAttribute("nonce",E),e.appendChild(P.createTextNode(n)),P.head.appendChild(e)}}else if(o.getAttribute("href")){if(o.hasAttribute("disabled"))s({messages:["`react-to-print` encountered a <link> tag with a `disabled` attribute and will ignore it. Note that the `disabled` attribute is deprecated, and some browsers ignore it. You should stop using it. https://developer.mozilla.org/en-US/docs/Web/HTML/Element/link#attr-disabled. The <link> is:",o],level:"warning"}),t(o);else{let e=P.createElement(o.tagName);for(let t=0,r=o.attributes.length;t<r;++t){let r=o.attributes[t];r&&e.setAttribute(r.nodeName,null!==(p=r.nodeValue)&&void 0!==p?p:"")}e.onload=()=>{t(e)},e.onerror=(r,o,n,i,s)=>{t(e,["Failed to load",e,"Error:",s])},E&&e.setAttribute("nonce",E),P.head.appendChild(e)}}else s({messages:["`react-to-print` encountered a <link> tag with an empty `href` attribute. In addition to being invalid HTML, this can cause problems in many browsers, and so the <link> was not loaded. The <link> is:",o],level:"warning"}),t(o)}}}0===g&&d(e,o)})(w,k,x,a)},document.body.appendChild(w)}a(g,!0),m?m().then(()=>{w()}).catch(e=>{null==h||h("onBeforePrint",l(e))}):w()},[e,t,r,o,n,u,p,f,m,h,y,g,b,v])}return n}()},e.exports=o(r(9300))},7234:function(e,t,r){"use strict";r.d(t,{WV:function(){return s}});var o=r(9300);r(8691);var n=r(223),i=r(5444),s=["a","button","div","form","h2","h3","img","input","label","li","nav","ol","p","span","svg","ul"].reduce((e,t)=>{let r=o.forwardRef((e,r)=>{let{asChild:o,...s}=e,a=o?n.g7:t;return"undefined"!=typeof window&&(window[Symbol.for("radix-ui")]=!0),(0,i.jsx)(a,{...s,ref:r})});return r.displayName=`Primitive.${t}`,{...e,[t]:r}},{})},4611:function(e,t,r){"use strict";let o,n;r.d(t,{x7:function(){return ep},ZP:function(){return ef}});var i,s=r(9300);let a={data:""},l=e=>"object"==typeof window?((e?e.querySelector("#_goober"):window._goober)||Object.assign((e||document.head).appendChild(document.createElement("style")),{innerHTML:" ",id:"_goober"})).firstChild:e||a,d=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,c=/\/\*[^]*?\*\/|  +/g,u=/\n+/g,p=(e,t)=>{let r="",o="",n="";for(let i in e){let s=e[i];"@"==i[0]?"i"==i[1]?r=i+" "+s+";":o+="f"==i[1]?p(s,i):i+"{"+p(s,"k"==i[1]?"":t)+"}":"object"==typeof s?o+=p(s,t?t.replace(/([^,])+/g,e=>i.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):i):null!=s&&(i=/^--/.test(i)?i:i.replace(/[A-Z]/g,"-$&").toLowerCase(),n+=p.p?p.p(i,s):i+":"+s+";")}return r+(t&&n?t+"{"+n+"}":n)+o},f={},m=e=>{if("object"==typeof e){let t="";for(let r in e)t+=r+m(e[r]);return t}return e},h=(e,t,r,o,n)=>{var i;let s=m(e),a=f[s]||(f[s]=(e=>{let t=0,r=11;for(;t<e.length;)r=101*r+e.charCodeAt(t++)>>>0;return"go"+r})(s));if(!f[a]){let t=s!==e?e:(e=>{let t,r,o=[{}];for(;t=d.exec(e.replace(c,""));)t[4]?o.shift():t[3]?(r=t[3].replace(u," ").trim(),o.unshift(o[0][r]=o[0][r]||{})):o[0][t[1]]=t[2].replace(u," ").trim();return o[0]})(e);f[a]=p(n?{["@keyframes "+a]:t}:t,r?"":"."+a)}let l=r&&f.g?f.g:null;return r&&(f.g=f[a]),i=f[a],l?t.data=t.data.replace(l,i):-1===t.data.indexOf(i)&&(t.data=o?i+t.data:t.data+i),a},y=(e,t,r)=>e.reduce((e,o,n)=>{let i=t[n];if(i&&i.call){let e=i(r),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;i=t?"."+t:e&&"object"==typeof e?e.props?"":p(e,""):!1===e?"":e}return e+o+(null==i?"":i)},"");function g(e){let t=this||{},r=e.call?e(t.p):e;return h(r.unshift?r.raw?y(r,[].slice.call(arguments,1),t.p):r.reduce((e,r)=>Object.assign(e,r&&r.call?r(t.p):r),{}):r,l(t.target),t.g,t.o,t.k)}g.bind({g:1});let b,v,w,x=g.bind({k:1});function k(e,t){let r=this||{};return function(){let o=arguments;function n(i,s){let a=Object.assign({},i),l=a.className||n.className;r.p=Object.assign({theme:v&&v()},a),r.o=/ *go\d+/.test(l),a.className=g.apply(r,o)+(l?" "+l:""),t&&(a.ref=s);let d=e;return e[0]&&(d=a.as||e,delete a.as),w&&d[0]&&w(a),b(d,a)}return t?t(n):n}}var E=e=>"function"==typeof e,A=(e,t)=>E(e)?e(t):e,C=(o=0,()=>(++o).toString()),P=()=>{if(void 0===n&&"u">typeof window){let e=matchMedia("(prefers-reduced-motion: reduce)");n=!e||e.matches}return n},S="default",T=(e,t)=>{let{toastLimit:r}=e.settings;switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,r)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:o}=t;return T(e,{type:e.toasts.find(e=>e.id===o.id)?1:0,toast:o});case 3:let{toastId:n}=t;return{...e,toasts:e.toasts.map(e=>e.id===n||void 0===n?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let i=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+i}))}}},N=[],M={toasts:[],pausedAt:void 0,settings:{toastLimit:20}},j={},D=(e,t=S)=>{j[t]=T(j[t]||M,e),N.forEach(([e,r])=>{e===t&&r(j[t])})},$=e=>Object.keys(j).forEach(t=>D(e,t)),O=e=>Object.keys(j).find(t=>j[t].toasts.some(t=>t.id===e)),R=(e=S)=>t=>{D(t,e)},Z={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},H=(e={},t=S)=>{let[r,o]=(0,s.useState)(j[t]||M),n=(0,s.useRef)(j[t]);(0,s.useEffect)(()=>(n.current!==j[t]&&o(j[t]),N.push([t,o]),()=>{let e=N.findIndex(([e])=>e===t);e>-1&&N.splice(e,1)}),[t]);let i=r.toasts.map(t=>{var r,o,n;return{...e,...e[t.type],...t,removeDelay:t.removeDelay||(null==(r=e[t.type])?void 0:r.removeDelay)||(null==e?void 0:e.removeDelay),duration:t.duration||(null==(o=e[t.type])?void 0:o.duration)||(null==e?void 0:e.duration)||Z[t.type],style:{...e.style,...null==(n=e[t.type])?void 0:n.style,...t.style}}});return{...r,toasts:i}},L=(e,t="blank",r)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...r,id:(null==r?void 0:r.id)||C()}),I=e=>(t,r)=>{let o=L(t,e,r);return R(o.toasterId||O(o.id))({type:2,toast:o}),o.id},F=(e,t)=>I("blank")(e,t);F.error=I("error"),F.success=I("success"),F.loading=I("loading"),F.custom=I("custom"),F.dismiss=(e,t)=>{let r={type:3,toastId:e};t?R(t)(r):$(r)},F.dismissAll=e=>F.dismiss(void 0,e),F.remove=(e,t)=>{let r={type:4,toastId:e};t?R(t)(r):$(r)},F.removeAll=e=>F.remove(void 0,e),F.promise=(e,t,r)=>{let o=F.loading(t.loading,{...r,...null==r?void 0:r.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let n=t.success?A(t.success,e):void 0;return n?F.success(n,{id:o,...r,...null==r?void 0:r.success}):F.dismiss(o),e}).catch(e=>{let n=t.error?A(t.error,e):void 0;n?F.error(n,{id:o,...r,...null==r?void 0:r.error}):F.dismiss(o)}),e};var W=1e3,z=(e,t="default")=>{let{toasts:r,pausedAt:o}=H(e,t),n=(0,s.useRef)(new Map).current,i=(0,s.useCallback)((e,t=W)=>{if(n.has(e))return;let r=setTimeout(()=>{n.delete(e),a({type:4,toastId:e})},t);n.set(e,r)},[]);(0,s.useEffect)(()=>{if(o)return;let e=Date.now(),n=r.map(r=>{if(r.duration===1/0)return;let o=(r.duration||0)+r.pauseDuration-(e-r.createdAt);if(o<0){r.visible&&F.dismiss(r.id);return}return setTimeout(()=>F.dismiss(r.id,t),o)});return()=>{n.forEach(e=>e&&clearTimeout(e))}},[r,o,t]);let a=(0,s.useCallback)(R(t),[t]),l=(0,s.useCallback)(()=>{a({type:5,time:Date.now()})},[a]),d=(0,s.useCallback)((e,t)=>{a({type:1,toast:{id:e,height:t}})},[a]),c=(0,s.useCallback)(()=>{o&&a({type:6,time:Date.now()})},[o,a]),u=(0,s.useCallback)((e,t)=>{let{reverseOrder:o=!1,gutter:n=8,defaultPosition:i}=t||{},s=r.filter(t=>(t.position||i)===(e.position||i)&&t.height),a=s.findIndex(t=>t.id===e.id),l=s.filter((e,t)=>t<a&&e.visible).length;return s.filter(e=>e.visible).slice(...o?[l+1]:[0,l]).reduce((e,t)=>e+(t.height||0)+n,0)},[r]);return(0,s.useEffect)(()=>{r.forEach(e=>{if(e.dismissed)i(e.id,e.removeDelay);else{let t=n.get(e.id);t&&(clearTimeout(t),n.delete(e.id))}})},[r,i]),{toasts:r,handlers:{updateHeight:d,startPause:l,endPause:c,calculateOffset:u}}},q=x`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,B=x`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,_=x`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,U=k("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${q} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${B} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${_} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,V=x`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,G=k("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${V} 1s linear infinite;
`,Y=x`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,X=x`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,J=k("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${Y} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${X} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,K=k("div")`
  position: absolute;
`,Q=k("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,ee=x`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,et=k("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${ee} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,er=({toast:e})=>{let{icon:t,type:r,iconTheme:o}=e;return void 0!==t?"string"==typeof t?s.createElement(et,null,t):t:"blank"===r?null:s.createElement(Q,null,s.createElement(G,{...o}),"loading"!==r&&s.createElement(K,null,"error"===r?s.createElement(U,{...o}):s.createElement(J,{...o})))},eo=e=>`
0% {transform: translate3d(0,${-200*e}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,en=e=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*e}%,-1px) scale(.6); opacity:0;}
`,ei=k("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,es=k("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,ea=(e,t)=>{let r=e.includes("top")?1:-1,[o,n]=P()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[eo(r),en(r)];return{animation:t?`${x(o)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${x(n)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}},el=s.memo(({toast:e,position:t,style:r,children:o})=>{let n=e.height?ea(e.position||t||"top-center",e.visible):{opacity:0},i=s.createElement(er,{toast:e}),a=s.createElement(es,{...e.ariaProps},A(e.message,e));return s.createElement(ei,{className:e.className,style:{...n,...r,...e.style}},"function"==typeof o?o({icon:i,message:a}):s.createElement(s.Fragment,null,i,a))});i=s.createElement,p.p=void 0,b=i,v=void 0,w=void 0;var ed=({id:e,className:t,style:r,onHeightUpdate:o,children:n})=>{let i=s.useCallback(t=>{if(t){let r=()=>{o(e,t.getBoundingClientRect().height)};r(),new MutationObserver(r).observe(t,{subtree:!0,childList:!0,characterData:!0})}},[e,o]);return s.createElement("div",{ref:i,className:t,style:r},n)},ec=(e,t)=>{let r=e.includes("top"),o=e.includes("center")?{justifyContent:"center"}:e.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:P()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${t*(r?1:-1)}px)`,...r?{top:0}:{bottom:0},...o}},eu=g`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,ep=({reverseOrder:e,position:t="top-center",toastOptions:r,gutter:o,children:n,toasterId:i,containerStyle:a,containerClassName:l})=>{let{toasts:d,handlers:c}=z(r,i);return s.createElement("div",{"data-rht-toaster":i||"",style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...a},className:l,onMouseEnter:c.startPause,onMouseLeave:c.endPause},d.map(r=>{let i=r.position||t,a=ec(i,c.calculateOffset(r,{reverseOrder:e,gutter:o,defaultPosition:t}));return s.createElement(ed,{id:r.id,key:r.id,onHeightUpdate:c.updateHeight,className:r.visible?eu:"",style:a},"custom"===r.type?A(r.message,r):n?n(r):s.createElement(el,{toast:r,position:i}))}))},ef=F}}]);